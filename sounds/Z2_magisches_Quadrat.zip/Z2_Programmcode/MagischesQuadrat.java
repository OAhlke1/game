import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class MagischesQuadrat implements ActionListener
{ 
    JFrame fenster;
    Container c ;
    JLabel LUeberschrift;

    JTextField AOne, ATwo, AThree, BOne, BTwo, BThree, COne, CTwo, CThree;
    
    JButton Bcheck;
    

       
    public MagischesQuadrat ()
    {
        fenster = new JFrame ("Magisches-Quadrat-Prüfer");
        c=fenster.getContentPane();
        c.setLayout(null);
        fenster.setLocation(95,45);
        fenster.setSize (300,300);
        fenster.setLocationRelativeTo(null);
        
        LUeberschrift = new JLabel("Liegt ein magisches Quadrat vor?");
        LUeberschrift.setBounds(10,10,300,35);
        c.add(LUeberschrift);
        
        AOne = new JTextField("");
        AOne.setBounds(30,50,30,20);
        c.add(AOne);
        
        ATwo = new JTextField("");
        ATwo.setBounds(70,50,30,20);
        c.add(ATwo);
        
        AThree = new JTextField("");
        AThree.setBounds(110,50,30,20);
        c.add(AThree);
        
        BOne = new JTextField("");
        BOne.setBounds(30,80,30,20);
        c.add(BOne);
        
        BTwo = new JTextField("");
        BTwo.setBounds(70,80,30,20);
        c.add(BTwo);
        
        BThree = new JTextField("");
        BThree.setBounds(110,80,30,20);
        c.add(BThree);
        
        COne = new JTextField("");
        COne.setBounds(30,110,30,20);
        c.add(COne);
        
        CTwo = new JTextField("");
        CTwo.setBounds(70,110,30,20);
        c.add(CTwo);
        
        CThree = new JTextField("");
        CThree.setBounds(110,110,30,20);
        c.add(CThree);
        
        Bcheck = new JButton("überprüfen");
        Bcheck.setBounds(30,140,110,20);
        c.add(Bcheck);
        
        Bcheck.addActionListener(this);
        
               
        fenster.setVisible(true);
    }
        
        public void actionPerformed (ActionEvent ae)
       {
                          
           if(ae.getSource() == this.Bcheck)
           {
        }
        
        
        
        
    }
    
    
    
}